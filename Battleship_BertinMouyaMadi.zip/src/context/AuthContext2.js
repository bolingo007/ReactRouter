import React from 'react';

export const AuthContext2 = React.createContext({
    auth2: {},
    setAuth2: ()=> {}
});

