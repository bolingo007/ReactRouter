import React from 'react';

export const AuthContextJeu = React.createContext({
    authJeu: {},
    setAuthJeu: []
    //setAuthJeu: ()=> {}
});

