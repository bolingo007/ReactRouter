export default function APropos () {
    return (
        <div className="apropos">
            <h3>Bertin Mouya Madi</h3>
            {/* <div className="affiche"> */}
                <img src="./images/portrait.jpg" alt="Avatar" className="image" width="2" height='2'/>
                {/*<div className="middle">
                    <div className="text">Bertin Mouya Madi</div>
                </div> */}
            {/* </div> */}
            <p>C'est un projet collégial, permettant à deux joueurs de faire une bataille navale.</p>
            <p>Developpement en cours</p>
        </div>
    )

} 