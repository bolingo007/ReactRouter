export default function Accueil () {
    return (
        <div>
            <h1>Bataille navale</h1>
            <p>Ce jeu n'est pas encore terminé. </p>
            <p>Il faut faire un contexte de jeu qui marche bien. </p>
            <p>Il faut ajouter des sockets pour permettre à deux personnes de jouer. </p>
            <p>C'est un projet intéressant que je terminerai pendant mes vacances. Jtravaillerai dessus de temps en temps pour ajouter les parties manquantes</p>
        </div>
    )

} 